XML-RPC.NET - XML-RPC for .NET 
v0.9.0
Copyright (C) 2001-2004 Charles Cook (charlescook@ukonline.co.uk)

xmlrpcgen 
Copyright (C) 2003 Joe Bork

License is MIT X11.

For more information about XML-RPC refer to http://www.xmlrpc.com/

PREQUISITES
-----------
.NET Runtime 1.0 or 1.1


DOCUMENTATION
-------------
Open doc/index.html in a web-browser
